library(testthat)
library(puls)

test_check("puls")
